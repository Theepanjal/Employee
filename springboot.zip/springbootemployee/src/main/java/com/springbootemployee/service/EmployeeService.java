package com.springbootemployee.service;

import org.springframework.stereotype.Component;

import com.springbootemployee.entity.Employee;

@Component
public interface EmployeeService {

	public Employee save(Employee employee);
	public Employee update(Employee employee);
	public Employee get(Long id);
	public void delete(Employee employee);
}
