package com.springbootemployee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.springbootemployee.entity.Employee;
import com.springbootemployee.repository.EmployeeRepository;
import com.springbootemployee.service.EmployeeService;

@RestController
@RequestMapping("/mployee")
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;
	
	@Autowired
	private EmployeeRepository employeeRepository;

	@PostMapping("/create")
	public Employee createEmployee(@RequestBody Employee employee) {
		Employee createResponse = employeeService.save(employee);
		return createResponse;
	}


	
	@GetMapping(value = "/home")
	public ModelAndView homePage() {
		ModelAndView modelAndView = new ModelAndView("index");
		modelAndView.addObject("employee", new Employee());
		return modelAndView;
	}
	
	@GetMapping(value = "/createemployee")
	public ModelAndView createEmployeeView() {
		ModelAndView modelAndView = new ModelAndView("index");
		modelAndView.addObject("employee", new Employee());
		return modelAndView;
	}

	@PostMapping("/createemployee")
	public ModelAndView createEmployee1( Employee employee) {
		ModelAndView modelAndView = new ModelAndView();
		employeeService.save(employee);
		modelAndView.setViewName("saveemployee");
		//logger.info("Form submitted successfully.");
		return modelAndView;
	}
	
	@GetMapping("/getallemployeess")
	public ModelAndView getAllEmployees() {
		ModelAndView modelAndView = new ModelAndView();
	    List<Employee> employees = employeeRepository.findAll();
		modelAndView.addObject("employees", employees);
		modelAndView.setViewName("employeeinfo");
		//logger.info("Form submitted successfully.");
		return modelAndView;
	}
	

}
