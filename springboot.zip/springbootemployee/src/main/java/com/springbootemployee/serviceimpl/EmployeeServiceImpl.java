package com.springbootemployee.serviceimpl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.springbootemployee.entity.Employee;
import com.springbootemployee.repository.EmployeeRepository;
import com.springbootemployee.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepository employeeRepository;

	@Transactional
	public Employee save(Employee employee) {
		Employee createResponse = employeeRepository.save(employee);
		return createResponse;
	}

	@Transactional
	public Employee update(Employee employee) {
		Employee updateResponse = employeeRepository.save(employee);
		return updateResponse;
	}

	@Transactional
	public Employee get(Long id) {
		Optional<Employee> response = employeeRepository.findById(id);
		Employee getResponse = response.get();
		return getResponse;
	}

	@Transactional
	public void delete(Employee employee) {
		employeeRepository.delete(employee);
	}
}
